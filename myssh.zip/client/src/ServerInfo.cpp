#include <ServerInfo.hpp>



ServerInfo::ServerInfo()
{}
ServerInfo::~ServerInfo()
{}
