# MySSH
## Prerequisites
- Linux (tested on Debian 9)
- Crypto++ (tested version 5.6.4)
- Doxygen
- GNU Make
