var searchData=
[
  ['binderror',['BindError',['../classSocket_1_1BindError.html',1,'Socket']]]
];
