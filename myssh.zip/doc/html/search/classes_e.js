var searchData=
[
  ['senderror',['SendError',['../classSocket_1_1SendError.html',1,'Socket']]],
  ['server',['Server',['../classServer.html',1,'']]],
  ['serverinfo',['ServerInfo',['../classServerInfo.html',1,'']]],
  ['setsizeerror',['SetSizeError',['../classPipe_1_1SetSizeError.html',1,'Pipe']]],
  ['socket',['Socket',['../classSocket.html',1,'']]]
];
