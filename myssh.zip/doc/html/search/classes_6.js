var searchData=
[
  ['gethostaddresserror',['GetHostAddressError',['../classIpAddress_1_1GetHostAddressError.html',1,'IpAddress']]],
  ['getporterror',['GetPortError',['../classSocket_1_1GetPortError.html',1,'Socket']]]
];
