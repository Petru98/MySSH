var searchData=
[
  ['udp',['Udp',['../classSocket.html#a887cb6a692f34384c95410113fbf47e3a2be0ce0a4c9300e896c679eaec6b0372',1,'Socket']]],
  ['unix',['Unix',['../classSocket.html#ae9a5c463c3d6c7983c9b7cf3745fd8aaa54462d3a8787f0431f6579462e4f4bf2',1,'Socket']]]
];
