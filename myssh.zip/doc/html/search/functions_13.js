var searchData=
[
  ['warning',['warning',['../group__shared.html#ga1a684a7bdfd73a0b441960754ba5f286',1,'warning(const char *fmt,...):&#160;Logging.cpp'],['../Logging_8cpp.html#a1a684a7bdfd73a0b441960754ba5f286',1,'warning(const char *fmt,...):&#160;Logging.cpp']]],
  ['what',['what',['../classClientInfo_1_1DisconnectedError.html#ae410bc9ccd99958a91cf9efe0c5ba209',1,'ClientInfo::DisconnectedError']]],
  ['write',['write',['../classFileDescriptor.html#afe2ccaa68f9da93722dff456a6eef16c',1,'FileDescriptor::write()'],['../classPipe.html#a748080f6a234d91f0329ce8479bb38b2',1,'Pipe::write()']]],
  ['writeall',['writeAll',['../classFileDescriptor.html#a73aee6b1f1dbdc1e971497e6c6aeec27',1,'FileDescriptor']]]
];
