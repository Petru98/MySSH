var searchData=
[
  ['ip',['ip',['../classClientInfo.html#a34dff9a9564f6f7a59907dfa5dbcd658',1,'ClientInfo::ip()'],['../classServerInfo.html#ac1eaf9a2757ce89ef8192899c2c1eee9',1,'ServerInfo::ip()']]]
];
