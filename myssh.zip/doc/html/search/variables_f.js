var searchData=
[
  ['server',['server',['../classClient.html#ac25b83dd69ac0f5ed49562c017da772d',1,'Client']]],
  ['server_5fpipe',['server_pipe',['../classClientInfo.html#a89b4358c494169198ef71bf10c400b70',1,'ClientInfo']]],
  ['size',['size',['../classCommandTree.html#a31f18064fdc2fb58a3a2c15cf4bc4f6b',1,'CommandTree']]],
  ['sock',['sock',['../classClientInfo.html#a944623697524c1f9688f9dbab7caf7af',1,'ClientInfo::sock()'],['../classServerInfo.html#ab5cc300ffd00d6ec5c4a42c6557a4832',1,'ServerInfo::sock()']]],
  ['stderr_5ffilename',['stderr_filename',['../structCommandTree_1_1Node.html#a64e4ca7a030c6e312e53d44cd0b8a938',1,'CommandTree::Node']]],
  ['stdin_5ffilename',['stdin_filename',['../structCommandTree_1_1Node.html#a6d11332d06f32941e8e71732d699f8a5',1,'CommandTree::Node']]],
  ['stdout_5ffilename',['stdout_filename',['../structCommandTree_1_1Node.html#a7c472dc57fee07bd2f4b3e1258d037d5',1,'CommandTree::Node']]]
];
