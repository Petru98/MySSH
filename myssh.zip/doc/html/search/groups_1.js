var searchData=
[
  ['server_20module',['Server module',['../group__server.html',1,'']]],
  ['shared_20module',['Shared module',['../group__shared.html',1,'']]]
];
