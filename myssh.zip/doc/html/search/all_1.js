var searchData=
[
  ['bind',['bind',['../classSocket.html#afbba985e7293ce5429f6f623e231e776',1,'Socket']]],
  ['binderror',['BindError',['../classSocket_1_1BindError.html',1,'Socket']]],
  ['buffer',['buffer',['../classSocket.html#a94ca6c485a639d42afc7328067b81b07',1,'Socket']]]
];
