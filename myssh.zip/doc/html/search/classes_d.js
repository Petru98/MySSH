var searchData=
[
  ['readerror',['ReadError',['../classFileDescriptor_1_1ReadError.html',1,'FileDescriptor']]],
  ['receiveerror',['ReceiveError',['../classSocket_1_1ReceiveError.html',1,'Socket']]]
];
