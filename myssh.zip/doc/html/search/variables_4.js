var searchData=
[
  ['encode_5fkey',['encode_key',['../classPgpSocket.html#abf6ac4f2d2205470039a849331b1646a',1,'PgpSocket']]],
  ['errmsg',['errmsg',['../classClientInfo.html#aaa3179a15830245cb8fc11ce69a31645',1,'ClientInfo']]],
  ['errmsg_5fmax_5fsize',['ERRMSG_MAX_SIZE',['../classClientInfo.html#a37f06001645032430c5d289e229a18ed',1,'ClientInfo']]]
];
