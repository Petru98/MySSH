var searchData=
[
  ['joinerror',['JoinError',['../classThread_1_1JoinError.html',1,'Thread']]]
];
