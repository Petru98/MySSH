var searchData=
[
  ['detacherror',['DetachError',['../classThread_1_1DetachError.html',1,'Thread']]],
  ['disconnectederror',['DisconnectedError',['../classClientInfo_1_1DisconnectedError.html',1,'ClientInfo']]]
];
