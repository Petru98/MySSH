var searchData=
[
  ['writeerror',['WriteError',['../classFileDescriptor_1_1WriteError.html',1,'FileDescriptor']]]
];
