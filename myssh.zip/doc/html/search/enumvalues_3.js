var searchData=
[
  ['local',['Local',['../classSocket.html#ae9a5c463c3d6c7983c9b7cf3745fd8aaae84ecf85aa5f4e888e9164a5437b2c02',1,'Socket']]]
];
